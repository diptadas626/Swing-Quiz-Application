package SwingQuizApp;

public class Question {
    private String text;
    private String[] options;
    private int correctAns;

    public Question (String text, String[] options, int correctAns){
        this.text = text;
        this.options = options;
        this.correctAns = correctAns;
    }

    public String getText(){
        return text;
    }

    public String[] getOptions() {
        return options;
    }

    public int getCorrectAns() {
        return correctAns;
    }
}
