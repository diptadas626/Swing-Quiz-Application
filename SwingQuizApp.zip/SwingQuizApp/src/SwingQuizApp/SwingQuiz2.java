package SwingQuizApp;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SwingQuiz2 {
    private JFrame mainFrame;
    private JButton startQuizButton;

    public SwingQuiz2(){

        mainFrame = new JFrame("Quiz Application");
        mainFrame.setSize(400,200);
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainFrame.setLayout(new BorderLayout());

        JLabel titleLebel = new JLabel("Welcome to the Swing Quiz", JLabel.CENTER);
        mainFrame.add(titleLebel, BorderLayout.NORTH);

        startQuizButton = new JButton("Start Quiz");
        startQuizButton.setFont(new Font("Arial",Font.PLAIN,18));
        startQuizButton.setFocusPainted(false);

        mainFrame.add(startQuizButton, BorderLayout.CENTER);

        startQuizButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new SwingQuiz();
                mainFrame.dispose();
            }
        });
        mainFrame.setVisible(true);
    }

    public static void main(String[] args) {
        new SwingQuiz2();
    }


}




