package SwingQuizApp;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;



public class SwingQuiz {
    public JFrame frame;
    public JPanel panel;
    public JLabel questionLabel;
    public JRadioButton[] rButton;
    public ButtonGroup group;
    public JButton nextButton, finishButton;

    public ArrayList<Question> question;
    public int index = 0;
    public int score = 0;

    public SwingQuiz(){
        frame = new JFrame("Swing Quiz");
        frame.setSize(400,400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        panel = new JPanel();
        panel.setLayout(new BorderLayout());

        questionLabel = new JLabel("Question will be displayed here");
        panel.add(questionLabel, BorderLayout.NORTH);

        rButton = new JRadioButton[4];
        group = new ButtonGroup();

        JPanel optionPanel = new JPanel();
        optionPanel.setLayout(new GridLayout(4,1));

        for(int i = 0; i< rButton.length; i++){
            rButton[i] = new JRadioButton();
            group.add(rButton[i]);
            optionPanel.add(rButton[i]);
        }

        panel.add(optionPanel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        nextButton = new JButton("Next");
        finishButton = new JButton("Finish");

        buttonPanel.add(nextButton);
        buttonPanel.add(finishButton);

        finishButton.setVisible(false);

        panel.add(buttonPanel, BorderLayout.SOUTH);

        frame.add(panel);
        frame.setVisible(true);

        loadQuestion("question.txt");

        display(index);

        nextButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                checkAns();
                index++;
                if(index < question.size()){
                    display(index);
                }
                else {
                    nextButton.setVisible(false);
                    finishButton.setVisible(true);
                }
            }
        });

        finishButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                checkAns();
                JOptionPane.showMessageDialog(frame, "Your score is: "+ score + "/" + question.size());
                finishButton.setEnabled(false);
            }
        });


    }

    public void loadQuestion(String fileName){
        question = new ArrayList<>();
        try(BufferedReader br = new BufferedReader(new FileReader(fileName))){
            String line;

            while ((line = br.readLine()) != null){
                String questionText = line;
                String[] option = br.readLine().split(";");
                int correctAns = Integer.parseInt(br.readLine());
                question.add(new Question(questionText, option, correctAns));
            }
        }
        catch (IOException e){
            e.printStackTrace();
        }

    }

    public void display(int index){
        group.clearSelection();
        Question ques = question.get(index);
        questionLabel.setText(ques.getText());

        String[] option = ques.getOptions();

        for(int i = 0; i< option.length; i++){
            rButton[i].setText(option[i]);
            rButton[i].setSelected(false);
        }

    }

    public void checkAns(){
        int selectedOption = -1;
        for(int i = 0; i< rButton.length; i++){
            if(rButton[i].isSelected()){
                selectedOption = i+1;
                break;
            }
        }

        if(index >= 0 && index < question.size()) {
            if (selectedOption == question.get(index).getCorrectAns()) {
                score++;
            }
        }

    }



}
